package com.example.myapplication

import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var passwordList: ListView
    private lateinit var addButton: Button
    private lateinit var passwordAdapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        passwordList = findViewById(R.id.passwordList)
        addButton = findViewById(R.id.addButton)

        val passwords = ArrayList<String>()
        passwordAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, passwords)
        passwordList.adapter = passwordAdapter

        addButton.setOnClickListener {
            // Implementar lógica para exibir a tela de configuração de senha
        }

        passwordList.setOnItemClickListener { _, _, position, _ ->
            val selectedPassword = passwordAdapter.getItem(position)
            // Implementar lógica para exibir o formulário com as configurações da senha selecionada
        }

        passwordList.setOnItemLongClickListener { _, _, position, _ ->
            val selectedPassword = passwordAdapter.getItem(position)
            // Implementar lógica para copiar a senha para a área de transferência
            copyToClipboard(selectedPassword)
            true
        }
    }

    private fun copyToClipboard(text: String?) {
        val clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clipData = android.content.ClipData.newPlainText("Password", text)
        clipboardManager.setPrimaryClip(clipData)
        // Exibir uma mensagem indicando que a senha foi copiada para a área de transferência
    }
}
